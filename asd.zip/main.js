const { app, BrowserWindow, Menu, globalShortcut, ipcMain } = require('electron')
const path = require('path')

process.env.NODE_ENV = 'development'

const isDev = process.env.NODE_ENV !== 'production' ? true: false

let win

const createWindow = () => {
	win = new BrowserWindow({
		width: 800,
		height: 600,
		icon: './assets/icon.png',
		webPreferences: {
			preload: path.join(__dirname, './preload.js'),
			nodeIntegration: true
		},
		resizable: true,

	})
	win.loadFile('./index.html')
}

app.on('window-all-closed', () => {
	if (process.platform !== 'darwin') app.quit()
})

const menu = [
	{
		role: 'fileMenu'
	}
]

ipcMain.on('counter-value', (_event, value) => {
	console.log(value) // will print value to Node console
})



app.whenReady().then(() => {
	app.on('activate', () => {
		if (BrowserWindow.getAllWindows().length === 0) createWindow()
	})



	setInterval(() => {
		ipcMain.on('counter-value', (_event, value) => {
			console.log(value) // will print value to Node console
		})
	}, 1000)

	createWindow()

	const mainMenu = Menu.buildFromTemplate(menu)
	Menu.setApplicationMenu(mainMenu)
	win.webContents.openDevTools()
})