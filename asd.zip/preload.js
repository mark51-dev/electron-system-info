const { contextBridge, ipcRenderer } = require('electron')

contextBridge.exposeInMainWorld('electronAPI', {
    cpuModel: (callback) => ipcRenderer.on('pc-info:cpuModel', callback),
    hostName: (callback) => ipcRenderer.on('pc-info:hostName', callback),
    operationSystem: (callback) => ipcRenderer.on('pc-info:os', callback),
    systemUptime: (callback) => ipcRenderer.on('pc-info:systemUptime', callback),
    systemMemory: (callback) => ipcRenderer.on('pc-info:systemUptime', callback),
})

