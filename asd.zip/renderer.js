const cpuUsage = document.getElementById('cpu-usage')

window.electronAPI.cpuModel('pc-info:cpuModel', (event, value) => {
	console.log('asdasd')
	cpuUsage.innerText = value
	event.sender.send('pc-info:cpuModel', value)
})